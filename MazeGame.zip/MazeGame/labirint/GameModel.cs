using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
 
namespace MazeGame
{
    public class GameModel
    {
        public static Random random;

        public static int Size;
        public Player player;
        public Path path;
        public Maze maze;

        public void StartGame()
        {
            maze.MakeEmptyMaze();
            path.MakePath(maze, player.position);
            maze.FillMaze(path);
            maze.AddCreeps(10, player);
            maze.AddItems(10, player);
        }

        public GameModel(int size)
        {
            random = new Random();
            Size = size;
            path = new Path();
            maze = new Maze();
            player = new Player(0, Size / 2);
            StartGame();
        }

        public class Player
        {
            public Player(int x, int y)
            {
                position = new MapPoint(x, y);
            }

            public MapPoint position;
            public int Score = 0;
            public int health = 3;
            public bool haveShield = false;
            public bool haveSword = false;

            public bool IsDead()
            {
                if (health <= 0)
                    return true;

                return false;
            }

            public bool Move(Keys k, Maze maze)
            {
                if (k == Keys.Up)
                    if (position.Y - 1 >= 0 && position.Y - 1 < Size && maze.mapPoints[position.X, position.Y - 1].isEmpty)
                    {
                        position.Y--;
                        return true;
                    }
                if (k == Keys.Down)
                    if (position.Y + 1 >= 0 && position.Y + 1 < Size && maze.mapPoints[position.X, position.Y + 1].isEmpty)
                    {
                        position.Y++;
                        return true;
                    }
                if (k == Keys.Left)
                    if (position.X - 1 >= 0 && position.X - 1 < Size && maze.mapPoints[position.X - 1, position.Y].isEmpty)
                    {
                        position.X--;
                        return true;
                    }
                if (k == Keys.Right)
                    if (position.X + 1 >= 0 && position.X + 1 < Size && maze.mapPoints[position.X + 1, position.Y].isEmpty)
                    {
                        position.X++;
                        return true;
                    }

                return false;
            }

            public void CheckItems(Maze maze)
            {
                foreach (var item in maze.items)
                {
                    if (item.position != null && position.X == item.position.X && position.Y == item.position.Y)
                    {
                        if (item.bonus == "medkit")
                        {
                            health++;
                            if (health > 5)
                                health = 5;
                        }

                        if (item.bonus == "sword")
                        {
                            haveSword = true;
                        }

                        if (item.bonus == "shield")
                        {
                            haveShield = true;
                        }

                        if (item.bonus == "extrapoint")
                        {
                            Score += 3;
                        }
                        item.position = null;
                    }
                }
            }

            public void CheckCreeps(Maze maze)
            {
                foreach (var creep in maze.creeps)
                {
                    if (creep.position != null && position.X == creep.position.X && position.Y == creep.position.Y)
                    {
                        if (haveSword)
                        {
                            creep.position = null;
                            haveSword = false;
                            Score += creep.score;
                        }
                        if (haveShield)
                        {
                            haveShield = false;
                        }
                        else
                        {
                            health -= creep.damage;
                        }
                    }
                }
            }


        }

        public class Creep
        {
            public MapPoint position;

            public int damage;
            public int score;
            public string className;

            public Dictionary<string, int[]> specificationsClass = new Dictionary<string, int[]>() { { "simple", new int[2] { 1, 1 } }, { "elite", new int[2] { 3, 3 } } };
            public List<string> classList = new List<string>() { "simple", "elite" };

            public void CreateCreep(Maze maze, Player player)
            {
                var tmp = new List<MapPoint>();
                for (var i = 0; i < Size - 1; i++)
                    for (var j = 0; j < Size; j++)
                    {
                        if (maze.mapPoints[i, j].isEmpty && player.position.X != i && player.position.Y != j)
                            tmp.Add(maze.mapPoints[i, j]);
                    }
                //var random = new Random();
                var tmp1 = classList[random.Next() % 2];
                damage = specificationsClass[tmp1][0];
                score = specificationsClass[tmp1][1];
                className = tmp1;
                position = tmp[random.Next() % tmp.Count];
            }

            public void CreepMove(Maze maze)
            {
                //var random = new Random();
                var listInt = new List<int> { -1, 0, 1 };
                var r1 = listInt[random.Next() % 3];
                var r2 = 0;
                if (r1 == 0)
                    r2 = listInt[random.Next() % 3];

                if (position != null && r1 + position.X >= 0 && r1 + position.X < Size - 2 && r2 + position.Y >= 0 && r2 + position.Y < Size - 1)
                {
                    if (maze.mapPoints[r1 + position.X, r2 + position.Y].isEmpty)
                    {
                        position = maze.mapPoints[r1 + position.X, r2 + position.Y];
                    }
                }
            }
        }

        public class Item
        {
            public MapPoint position;

            public string bonus;

            public void CreateItem(Maze maze, Player player)
            {
                var tmp = new List<MapPoint>();
                for (var i = 0; i < Size - 1; i++)
                    for (var j = 0; j < Size; j++)
                    {
                        if (maze.mapPoints[i, j].isEmpty && player.position.X != i && player.position.Y != j)
                            tmp.Add(maze.mapPoints[i, j]);
                    }
                //var random = new Random();
                position = tmp[random.Next() % tmp.Count];
                var listBonus = new List<string>() { "medkit", "sword", "shield", "extrapoint" };
                bonus = listBonus[random.Next() % 4];
            }
        }


        public class Path
        {
            public void ClearPath()
            {
                pathPoints.Clear();
            }

            public LinkedList<MapPoint> pathPoints = new LinkedList<MapPoint>();
            public void MakePath(Maze maze, MapPoint startPoint)
            {
                //var random = new Random();
                maze.mapPoints[startPoint.X, startPoint.Y].isInPath = true;
                pathPoints.AddFirst(maze.mapPoints[startPoint.X, startPoint.Y]);
                var visited = new List<MapPoint>();
                visited.Add(pathPoints.Last.Value);
                var prevPoint = new MapPoint(-1, -1);
                while (true)
                {
                    if (prevPoint == pathPoints.Last.Value)
                    {
                        maze.mapPoints[pathPoints.Last.Value.X, pathPoints.Last.Value.Y].isInPath = false;
                        pathPoints.RemoveLast();
                        continue;
                    }
                    prevPoint = pathPoints.Last.Value;
                    if (pathPoints.Last.Value.NearPoints.Count == 0)
                        pathPoints.Last.Value.setNeighbour(maze);

                    var pointsToVisit = new List<MapPoint>();

                    foreach (var p in pathPoints.Last.Value.NearPoints)
                        pointsToVisit.Add(p);
                    for (var i = 0; i < pointsToVisit.Count; i++)
                    {
                        if (visited.Contains(pointsToVisit[i]) || !pointsToVisit[i].isEmpty)
                        {
                            pointsToVisit.Remove(pointsToVisit[i]);
                        }
                    }
                    if (pointsToVisit.Count == 0)
                    {
                        visited.Add(pathPoints.Last.Value);
                        maze.mapPoints[pathPoints.Last.Value.X, pathPoints.Last.Value.Y].isInPath = false;
                        pathPoints.RemoveLast();
                        continue;
                    }
                    var r = random.Next() % pointsToVisit.Count;
                    if (!visited.Contains(pointsToVisit[r]))
                    {
                        pointsToVisit[r].isInPath = true;
                        visited.Add(pointsToVisit[r]);

                        pathPoints.AddLast(pointsToVisit[r]);
                        maze.mapPoints[pointsToVisit[r].X, pointsToVisit[r].Y] = pointsToVisit[r];
                        if (pathPoints.Last.Value.X == Size - 1)
                            break;
                    }
                }

                if (pathPoints.Count / 0.25 > Size * Size)
                {
                    //pathPoints.Clear();
                    foreach (var p in maze.mapPoints)
                        p.isInPath = false;
                    pathPoints = new LinkedList<MapPoint>();
                    MakePath(maze, startPoint);
                }
                return;
            }
        }

        public class Maze
        {
            public Item[] items;
            public Creep[] creeps;
            public MapPoint[,] mapPoints;

            public Maze()
            {
                mapPoints = new MapPoint[Size, Size];
            }

            public Maze MakeEmptyMaze()
            {
                for (var x = 0; x < Size; x++)
                    for (var y = 0; y < Size; y++)
                    {
                        this.mapPoints[x, y] = new MapPoint(x, y);
                    }
                return this;
            }

            public Maze MakePattern(Player player, Path path)
            {
                this.MakeEmptyMaze();

                player.position = this.mapPoints[0, player.position.Y];
                path.ClearPath();
                return this;
            }

            public Maze FillMaze(Path path)
            {

                var random = new Random();
                for (var x = 0; x < Size; x++)
                    for (var y = 0; y < Size; y++)
                    {
                        if (!path.pathPoints.Contains(this.mapPoints[x, y]))
                        {
                            if (random.Next() % 2 == 0)
                                this.mapPoints[x, y].isEmpty = true;
                            else
                                this.mapPoints[x, y].isEmpty = false;
                        }
                    }
                return this;
            }

            public void AddCreeps(int count, Player player)
            {
                creeps = new Creep[count];
                for (int i = 0; i < count; i++)
                {
                    creeps[i] = new Creep();
                    creeps[i].CreateCreep(this, player);
                }
            }

            public void AddItems(int count, Player player)
            {
                items = new Item[count];
                for (int i = 0; i < count; i++)
                {
                    items[i] = new Item();
                    items[i].CreateItem(this, player);
                }
            }
        }

        public class MapPoint
        {
            public bool isEmpty = true;
            public bool isInPath = false;
            public int X;
            public int Y;

            public List<MapPoint> NearPoints = new List<MapPoint>();

            public MapPoint(int x, int y)
            {
                X = x;
                Y = y;
            }



            public void setNeighbour(Maze maze)
            {
                for (var x = -1; x <= 1; x++)
                    for (var y = -1; y <= 1; y++)
                    {
                        if ((x != 0 && y != 0) || (x == 0 && y == 0))
                            continue;
                        if (this.X + x < 0 || this.X + x > Size - 1 || this.Y + y < 0 || this.Y + y > Size - 1)
                            continue;
                        this.NearPoints.Add(maze.mapPoints[this.X + x, this.Y + y]);
                    }
            }
        }
    }
}