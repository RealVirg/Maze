﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;


namespace MazeGame
{
    class GameForm : Form
    {
        GameModel game;
        readonly Image field = Image.FromFile("field.bmp");
        readonly Image wall = Image.FromFile("wall.bmp");
        readonly Image player = Image.FromFile("player.bmp");
        readonly Image creep = Image.FromFile("creep.bmp");
        readonly Image medkit = Image.FromFile("medkit.bmp");
        readonly Image sword = Image.FromFile("sword.bmp");
        readonly Image shield = Image.FromFile("shield.bmp");
        readonly Image coin = Image.FromFile("coin.bmp");
        readonly Image eliteCreep = Image.FromFile("elitecreep.bmp");

        Label label;

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;

            for (int x = 0; x < GameModel.Size; x++)
                for (int y = 0; y < GameModel.Size; y++)
                {
                    if (game.maze.mapPoints[x, y].isEmpty)
                        g.DrawImage(field, new Point(x * 25, y * 25));
                    if (!game.maze.mapPoints[x, y].isEmpty)
                        g.DrawImage(wall, new Point(x * 25, y * 25));
                }

            foreach (var i in game.maze.items)
            {
                if (i.position != null)
                {
                    if (i.bonus == "medkit")
                        g.DrawImage(medkit, new Point(i.position.X * 25, i.position.Y * 25));
                    if (i.bonus == "sword")
                        g.DrawImage(sword, new Point(i.position.X * 25, i.position.Y * 25));
                    if (i.bonus == "shield")
                        g.DrawImage(shield, new Point(i.position.X * 25, i.position.Y * 25));
                    if (i.bonus=="extrapoint")
                        g.DrawImage(coin, new Point(i.position.X * 25, i.position.Y * 25));
                }
            }

            foreach (var cr in game.maze.creeps)
            {
                if (cr.position != null)
                {
                    if (cr.className == "simple")
                        g.DrawImage(creep, new Point(cr.position.X * 25, cr.position.Y * 25));
                    if (cr.className == "elite")
                        g.DrawImage(eliteCreep, new Point(cr.position.X * 25, cr.position.Y * 25));
                }
            }

            g.DrawImage(player, new Point(game.player.position.X * 25, game.player.position.Y * 25));
        }

        public GameForm(GameModel game)
        {
            DoubleBuffered = true;

            this.game = game;

            var timer = new Timer();
            timer.Start();
            if (GameModel.Size==20)
                ClientSize = new Size(500,525);
            if (GameModel.Size==10)
                ClientSize = new Size(250, 275);
            if (GameModel.Size == 15)
                ClientSize = new Size(375, 400);

            label = new Label
            {
                Location = new Point(0, ClientSize.Height - 25),
                Height = 25,
                Width = ClientSize.Width,
                BackColor = Color.LightGreen,
                Text = "Score: " + game.player.Score + "   " + "Health: " + game.player.health
                            + "   " + "Inventory: ",

                TextAlign = ContentAlignment.MiddleCenter
            };

            Controls.Add(label);

            MaximizeBox = false;
            FormBorderStyle = FormBorderStyle.FixedDialog;


            this.KeyDown += new KeyEventHandler(OnMove);
        }

        public void MoveCreeps()
        {
            foreach (var e in game.maze.creeps)
            {
                e.CreepMove(game.maze);
            }
        }

        public void GameOver()
        {
            DialogResult dialogResult = MessageBox.Show("Your score: " + game.player.Score + "   Restart the game?",
                                                        "Game over",
                                                        MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.No)
            {
                Application.Exit();
            }

            if(dialogResult == DialogResult.Yes)
            {
                game = new GameModel(20);
                Refresh();
            }
        }

        public void UpdateDataLabel()
        {
            var tmp = "";
            if (game.player.haveSword)
                tmp = "sword ";
            else
                tmp = "";

            var tmp1 = "";
            if (game.player.haveShield)
                tmp1 = "shield";
            else
                tmp1 = "";
            label.Text = "Score: " + game.player.Score + "   " + "Health: " + game.player.health
                        + "   " + "Inventory: " + tmp + tmp1;
        }

        public void NewMaze()
        {
            var pattern = game.maze.MakePattern(game.player, game.path);
            game.path.MakePath(pattern, game.player.position);
            game.maze = game.maze.FillMaze(game.path);
            game.maze.AddItems(game.maze.items.Length, game.player);
            game.maze.AddCreeps(game.maze.creeps.Length, game.player);
            game.player.Score += 2;
            UpdateDataLabel();
        }

        private void OnMove(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down || e.KeyCode == Keys.Up || e.KeyCode == Keys.Left || e.KeyCode == Keys.Right)
            {
                var move = game.player.Move(e.KeyCode, game.maze);
              
                if (game.player.position.X == GameModel.Size - 1)
                {
                    NewMaze();
                }
                if (move)
                {
                    game.player.CheckItems(game.maze);
                    MoveCreeps();
                    game.player.CheckCreeps(game.maze);
                    UpdateDataLabel();
                    Refresh();

                    if (game.player.IsDead())
                        GameOver();
                }
            }
        }


    }
}