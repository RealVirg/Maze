﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace MazeGame
{
    class Program
    {
        public static void Main()
        {
            var game = new GameModel(20);
            Application.Run(new GameForm(game));
        }
    }
}
