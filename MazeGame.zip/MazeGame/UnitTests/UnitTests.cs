﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace UnitTests
{
    [TestClass]
    public class UnitTests
    {
        [TestMethod]
        public void TestSpawnCreeps()
        {
            var gamemodel = new MazeGame.GameModel(20);
            gamemodel.maze.AddCreeps(100000, gamemodel.player);
            foreach (var creep in gamemodel.maze.creeps)
            {
                Assert.AreNotEqual(gamemodel.player.position.X, creep.position.X);
                Assert.AreNotEqual(gamemodel.player.position.Y, creep.position.Y);
            }
        }

        [TestMethod]
        public void TestForCountPathPoint()
        {
            var gamemodel = new MazeGame.GameModel(20);
            var CountPathPoint = 0;
            foreach (var p in gamemodel.maze.mapPoints)
            {
                if (p.isInPath)
                    CountPathPoint++;
            }
            var check = false;
            if (CountPathPoint / 0.25 <= 20 * 20)
                check = true;
            Assert.AreEqual(true, check);
        }

        [TestMethod]
        public void TestSpawnItem()
        {
            var gamemodel = new MazeGame.GameModel(20);
            gamemodel.maze.AddItems(100000, gamemodel.player);
            foreach (var item in gamemodel.maze.items)
            {
                Assert.AreNotEqual(gamemodel.player.position.X, item.position.X);
                Assert.AreNotEqual(gamemodel.player.position.Y, item.position.Y);
            }
        }

        [TestMethod]
        public void TestForGoodPath()
        {
            for (var i = 0; i < 100; i++)
            {
                var gamemodel = new MazeGame.GameModel(20);
                var queue = new Queue<MazeGame.GameModel.MapPoint>();
                var visited = new List<MazeGame.GameModel.MapPoint>();
                var check = false;
                queue.Enqueue(gamemodel.maze.mapPoints[gamemodel.player.position.X, gamemodel.player.position.Y]);
                while (queue.Count != 0)
                {
                    var point = queue.Dequeue();
                    if (visited.Contains(point))
                        continue;
                    visited.Add(point);
                    if (point.NearPoints.Count == 0)
                        point.setNeighbour(gamemodel.maze);
                    foreach (var p in point.NearPoints)
                    {
                        if (p.isInPath)
                        {
                            queue.Enqueue(p);
                            if (p.X == 19)
                                check = true;
                        }
                        if (check)
                            break;
                    }
                    if (check)
                        break;
                }
                Assert.AreEqual(true, check);
            }
        }
        [TestMethod]
        public void TestToGetNearPoints()
        {
            var gamemodel = new MazeGame.GameModel(20);
            gamemodel.maze.mapPoints[0, 0].NearPoints.Clear();
            gamemodel.maze.mapPoints[0, 0].setNeighbour(gamemodel.maze);
            var check = gamemodel.maze.mapPoints[0, 0].NearPoints.Count == 2;
            gamemodel.maze.mapPoints[0, 1].NearPoints.Clear();
            gamemodel.maze.mapPoints[0, 1].setNeighbour(gamemodel.maze);
            var check1 = gamemodel.maze.mapPoints[0, 1].NearPoints.Count == 3;
            gamemodel.maze.mapPoints[1, 1].NearPoints.Clear();
            gamemodel.maze.mapPoints[1, 1].setNeighbour(gamemodel.maze);
            var check2 = gamemodel.maze.mapPoints[1, 1].NearPoints.Count == 4;
            Assert.AreEqual(true, check);
            Assert.AreEqual(true, check1);
            Assert.AreEqual(true, check2);
        }
        [TestMethod]
        public void TestMove()
        {
            var gamemodel = new MazeGame.GameModel(20);
            foreach (var p in gamemodel.maze.mapPoints)
            {
                p.isEmpty = true;
            }
            Assert.AreEqual(false, gamemodel.player.Move(Keys.Left, gamemodel.maze));
            Assert.AreEqual(true, gamemodel.player.Move(Keys.Up, gamemodel.maze));
            gamemodel.player.Move(Keys.Down, gamemodel.maze);
            Assert.AreEqual(true, gamemodel.player.Move(Keys.Down, gamemodel.maze));
            gamemodel.player.Move(Keys.Up, gamemodel.maze);
            Assert.AreEqual(true, gamemodel.player.Move(Keys.Right, gamemodel.maze));
            gamemodel.player.Move(Keys.Left, gamemodel.maze);
            gamemodel.player.position.X = 1;
            Assert.AreEqual(true, gamemodel.player.Move(Keys.Left, gamemodel.maze));
            gamemodel.player.Move(Keys.Right, gamemodel.maze);
            Assert.AreEqual(true, gamemodel.player.Move(Keys.Up, gamemodel.maze));
            gamemodel.player.Move(Keys.Down, gamemodel.maze);
            Assert.AreEqual(true, gamemodel.player.Move(Keys.Down, gamemodel.maze));
            gamemodel.player.Move(Keys.Up, gamemodel.maze);
            Assert.AreEqual(true, gamemodel.player.Move(Keys.Right, gamemodel.maze));
            gamemodel.player.Move(Keys.Left, gamemodel.maze);
            gamemodel.player.position.X = 0;
            gamemodel.player.position.Y = 0;
            Assert.AreEqual(false, gamemodel.player.Move(Keys.Left, gamemodel.maze));
            Assert.AreEqual(false, gamemodel.player.Move(Keys.Up, gamemodel.maze));
            Assert.AreEqual(true, gamemodel.player.Move(Keys.Down, gamemodel.maze));
            gamemodel.player.Move(Keys.Up, gamemodel.maze);
            Assert.AreEqual(true, gamemodel.player.Move(Keys.Right, gamemodel.maze));
            gamemodel.player.Move(Keys.Left, gamemodel.maze);
            gamemodel.maze.mapPoints[1, 0].isEmpty = false;
            Assert.AreEqual(false, gamemodel.player.Move(Keys.Right, gamemodel.maze));
        }
        [TestMethod]
        public void TestCheckItem()
        {
            for (var i = 0; i < 10000; i++)
            {
                var gamemodel = new MazeGame.GameModel(20);
                foreach (var p in gamemodel.maze.mapPoints)
                {
                    p.isEmpty = true;
                }
                foreach (var creep in gamemodel.maze.creeps)
                {
                    creep.position = null;
                }
                foreach (var item in gamemodel.maze.items)
                {
                    item.position = null;
                }
                gamemodel.player.position.X = 0;
                gamemodel.player.position.Y = 0;
                gamemodel.player.health = 3;
                gamemodel.maze.items[0].position = gamemodel.maze.mapPoints[1, 0];
                gamemodel.maze.items[0].bonus = "sword";
                Assert.AreEqual(false, gamemodel.player.haveSword);
                gamemodel.player.Move(Keys.Right, gamemodel.maze);
                gamemodel.player.CheckItems(gamemodel.maze);
                Assert.AreEqual(true, gamemodel.player.haveSword);
                gamemodel.maze.items[0].position = gamemodel.maze.mapPoints[1, 1];
                gamemodel.maze.items[0].bonus = "shield";
                Assert.AreEqual(false, gamemodel.player.haveShield);
                gamemodel.player.Move(Keys.Down, gamemodel.maze);
                gamemodel.player.CheckItems(gamemodel.maze);
                Assert.AreEqual(true, gamemodel.player.haveShield);
                gamemodel.maze.items[0].position = gamemodel.maze.mapPoints[1, 2];
                gamemodel.maze.items[0].bonus = "medkit";
                Assert.AreEqual(3, gamemodel.player.health);
                gamemodel.player.Move(Keys.Down, gamemodel.maze);
                gamemodel.player.CheckItems(gamemodel.maze);
                Assert.AreEqual(4, gamemodel.player.health);
                gamemodel.maze.items[0].position = gamemodel.maze.mapPoints[1, 3];
                gamemodel.maze.items[0].bonus = "extrapoint";
                Assert.AreEqual(0, gamemodel.player.Score);
                gamemodel.player.Move(Keys.Down, gamemodel.maze);
                gamemodel.player.CheckItems(gamemodel.maze);
                Assert.AreEqual(3, gamemodel.player.Score);
            }
        }
        [TestMethod]
        public void TestCheckMonster()
        {
            for (var i = 0; i < 10000; i++)
            {
                var gamemodel = new MazeGame.GameModel(20);
                foreach (var p in gamemodel.maze.mapPoints)
                {
                    p.isEmpty = true;
                }
                foreach (var creep in gamemodel.maze.creeps)
                {
                    creep.position = null;
                }
                foreach (var item in gamemodel.maze.items)
                {
                    item.position = null;
                }
                gamemodel.player.position.X = 0;
                gamemodel.player.position.Y = 0;
                gamemodel.player.health = 5;
                gamemodel.maze.creeps[0].position = gamemodel.maze.mapPoints[1, 0];
                gamemodel.player.Move(Keys.Right, gamemodel.maze);
                gamemodel.player.CheckCreeps(gamemodel.maze);
                Assert.AreEqual(5 - gamemodel.maze.creeps[0].damage, gamemodel.player.health);
                gamemodel.player.health = 5;
                gamemodel.player.haveSword = true;
                gamemodel.maze.creeps[1].position = gamemodel.maze.mapPoints[2, 0];
                gamemodel.player.Move(Keys.Right, gamemodel.maze);
                gamemodel.player.CheckCreeps(gamemodel.maze);
                Assert.AreEqual(5 - gamemodel.maze.creeps[1].damage, gamemodel.player.health);
                Assert.AreEqual(0 + gamemodel.maze.creeps[1].score, gamemodel.player.Score);
                Assert.AreEqual(null, gamemodel.maze.creeps[1].position);
                gamemodel.player.health = 5;
                gamemodel.player.haveShield = true;
                gamemodel.maze.creeps[1].position = gamemodel.maze.mapPoints[3, 0];
                gamemodel.player.Move(Keys.Right, gamemodel.maze);
                gamemodel.player.CheckCreeps(gamemodel.maze);
                Assert.AreEqual(5, gamemodel.player.health);
                Assert.AreEqual(true, gamemodel.maze.creeps[1].position != null);
            }
        }
    }
}