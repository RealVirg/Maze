﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace UnitTests
{
    [TestClass]
    public class UnitTests
    {
        [TestMethod]
        public void TestSpawnCreeps()
        {
            var gamemodel = new MazeGame.GameModel(20);
            gamemodel.maze.AddCreeps(100000, gamemodel.player);
            foreach (var creep in gamemodel.maze.creeps)
            {
                Assert.AreNotEqual(gamemodel.player.position.X, creep.position.X);
                Assert.AreNotEqual(gamemodel.player.position.Y, creep.position.Y);
            }
        }

        [TestMethod]
        public void TestSpawnItem()
        {
            var gamemodel = new MazeGame.GameModel(20);
            var i = 0;
            var j = 0;
            foreach (var p in gamemodel.maze.mapPoints)
            {
                if (p.isInPath)
                    i++;
                j++;
            }
            var check = false;
            if (i / 0.25 <= 20 * 20)
                check = true;
            Assert.AreEqual(true, check);
        }

        [TestMethod]
        public void Test3()
        {
            var gamemodel = new MazeGame.GameModel(20);
            gamemodel.maze.AddItems(100000, gamemodel.player);
            foreach (var item in gamemodel.maze.items)
            {
                Assert.AreNotEqual(gamemodel.player.position.X, item.position.X);
                Assert.AreNotEqual(gamemodel.player.position.Y, item.position.Y);
            }
        }

        [TestMethod]
        public void Test4()
        {
            var gamemodel = new MazeGame.GameModel(20);
            var queue = new Queue<MazeGame.GameModel.MapPoint>();
            var visited = new List<MazeGame.GameModel.MapPoint>();
            var check = false;
            queue.Enqueue(gamemodel.maze.mapPoints[gamemodel.player.position.X, gamemodel.player.position.Y]);
            while (queue.Count != 0)
            {
                var point = queue.Dequeue();
                if (visited.Contains(point))
                    continue;
                point.setNeighbour(gamemodel.maze);
                foreach (var p in point.NearPoints)
                {
                    if (p.isInPath)
                    {
                        queue.Enqueue(p);
                        visited.Add(p);
                        if (p.Y == 19)
                            check = true;
                    }
                    if (check)
                        break;
                }
                if (check)
                    break;
            }
            Assert.AreEqual(true, check);
            //    var gamemodel = new MazeGame.GameModel(20);
            //    var i = 0;
            //    foreach (var p in gamemodel.maze.mapPoints)
            //    {
            //        if (p.isInPath)
            //            i++;
            //    }
            //    Assert.AreEqual(1, i);
        }
    }
}
